// ConcatWave.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "wave.h"
int main(int argc, char* argv[])
{
	CWave wave1("a1.wav");
	CWave wave2("b7.wav");
	CWave wave3 = wave1+wave2;
	wave3.saveToFile();
	return 0;
}

